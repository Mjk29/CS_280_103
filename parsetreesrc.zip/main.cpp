//---------------------------------------------------------------------------
//
//  Recursive descent parser with assembly code output
//  Copyright Dmitry Brant, Spr 2004
//
//-----------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdexcept.h>
#include "grammar.h"

using std::runtime_error;
bool Translate(RewriteRuleGroup* group, char* input, TStringList* params, int level);
unsigned int currentTempCount, inputPtr, inputLength, verbosity=0;
String code;
Grammar* g;
//---------------------------------------------------------------------------


int main(int argc, char* argv[]){

    g = new Grammar();
    TStringList* params = new TStringList();
    char* inputStr = new char[32768]; //nice, big buffer for input

    try{

        g->LoadFromFile("grammar.txt");
        printf("\nGrammar loaded successfully.\n");
        inputStr[0] = 0;

        //what's this? do we have a command line argument?
        if(argc > 1){
            for(int i=1; i<argc; i++){
                if(!strcmp(argv[i], "-v")){
                    if(i<(argc-1)) verbosity = atoi(argv[i+1]);
                    i++;
                }else{
                    FILE* f = fopen(argv[1], "rb");
                    if(!f) throw runtime_error(("could not open " + String(argv[1]) + " for input").c_str());
                    unsigned int bytesread = fread(inputStr, 1, 32768, f);
                    fclose(f);
                    if(!bytesread) throw runtime_error(("could not read from file " + String(argv[1])).c_str());
                    inputLength = bytesread;
                    printf("Input loaded successfully.\n");
                }
            }
        }

        if(!inputStr[0]){
            printf("Please enter your input string:\n");
            gets(inputStr);
            inputLength = strlen(inputStr);
        }
        
        inputPtr = 0;
        currentTempCount = 0;

        //check this out:
        if(Translate(NULL, inputStr, params, 0)){

            //but wait, is there input left?!
            while((inputStr[inputPtr] <= ' ') && (inputPtr < inputLength)) inputPtr++;
            if(inputPtr < inputLength) throw runtime_error("input remaining after parsing");

            printf("\nString translated successfully!\n");
            FILE* f = fopen("out.txt", "w");
            if(f){
                fwrite(code.c_str(), 1, code.Length(), f);
                fclose(f);
                printf("Code written to out.txt\n");
            }

        }else{
            throw runtime_error("failed to parse string");
        }

    }catch(exception &e){
        printf("\nError: %s\n", e.what());
    }catch(...){
        printf("\nUnknown exception.\n");
    }

    delete g;
    delete [] inputStr;
    delete params;
    return 0;
}
//---------------------------------------------------------------------------


//From hell's heart, I stab at thee!
bool Translate(RewriteRuleGroup* group, char* input, TStringList* params, int level){

    RewriteRuleGroup* currentGroup;
    bool allUnitsSuccessful;

    //if no group was specified in the arguments, assume the start symbol
    if(group) currentGroup = group;
    else{
        if(!g->ruleGroups->Count) throw runtime_error("empty grammar");
        currentGroup = (RewriteRuleGroup*)g->ruleGroups->Items[0];
        if(verbosity > 0) printf(("\r\nUsing start symbol " + currentGroup->nonTerminal + "\n").c_str());
    }

    for(int j=0; j<currentGroup->rules->Count; j++){

        RewriteRule* currentRule = (RewriteRule*)currentGroup->rules->Items[j];
        allUnitsSuccessful=true;

        for(int k=0; k<currentRule->units->Count; k++){

            RewriteUnit* currentUnit = (RewriteUnit*)currentRule->units->Items[k];

            if(!currentUnit->codeGen){

                //if it's a nonterminal, call it!
                if(!currentUnit->terminal){
                    RewriteRuleGroup* newGroup=NULL;
                    //find which group it belongs to
                    for(int m=0; m<g->ruleGroups->Count; m++){
                        if(currentUnit->str == ((RewriteRuleGroup*)g->ruleGroups->Items[m])->nonTerminal){
                            newGroup = (RewriteRuleGroup*)g->ruleGroups->Items[m];
                        }
                    }
                    if(!newGroup) throw runtime_error(("no productions exist for nonterminal " + currentUnit->str).c_str());

                    if(verbosity > 0){
                        for(int z=0; z<level; z++) printf("  ");
                        printf(("Entering nonterminal " + currentUnit->str + "\n").c_str());
                    }

                    //Do the Timewarp! (that is, recursion)
                    bool result = Translate(newGroup, input, params, level+1);
                    if(!result) allUnitsSuccessful = false;

                    if(verbosity > 0){
                        for(int z=0; z<level; z++) printf("  ");
                        printf(("Exited nonterminal " + currentUnit->str + "\n").c_str());
                    }

                    if(!result) break;

                }else{

                    //it's a terminal
                    if(verbosity > 1){
                        for(int z=0; z<level; z++) printf("  ");
                        printf(("Expecting terminal \"" + currentUnit->str + "\"\n").c_str());
                    }

                    //wait... is it epsilon?
                    if(currentUnit->str == ""){
                        //just return immediately. I mean, come on.
                        break;

                    }else{

                        //look at input.
                        //eh, what the hell, process whitespace automatically
                        while((input[inputPtr] <= ' ') && (inputPtr < inputLength)) inputPtr++;
                        if(inputPtr >= inputLength){
                            //oops, we're out of input!
                            allUnitsSuccessful = false;
                            break;
                        }

                        if(String(input[inputPtr]) == currentUnit->str){
                            //it's good!
                            String ret = String(input[inputPtr]);
                            if(verbosity > 0){
                                for(int z=0; z<level; z++) printf("  ");
                                printf(("[---Processed terminal \"" + ret + "\"]\n").c_str());
                            }
                            inputPtr++;

                            //but don't add parentheses to the codegen stack, nor the semicolon
                            if((ret != '(') && (ret != ')') && (ret != ';'))
                                params->Add(ret);

                        }else{
                            //terminals don't match!
                            allUnitsSuccessful = false;

                            if(verbosity > 1){
                                for(int z=0; z<level; z++) printf("  ");
                                printf(("Actual terminal is \"" + String(input[inputPtr]) + "\"\n").c_str());
                            }
                            break;

                        } //if(match)
                    } //if(epsilon)
                } //if(terminal)

            }else{

                //generate code!
                currentTempCount++;

                String newTemp = ("T" + String(currentTempCount));
                String newCode;

                if(params->Count < 3){
                    throw runtime_error("syntax error");
                }

                int par1 = params->Count-3;
                int op = params->Count-2;
                int par2 = params->Count-1;

                //operation
                if(params->Strings[op] == "-"){
                    newCode += ("L " + params->Strings[par1] + "\n");
                    newCode += ("S " + params->Strings[par2] + "\n");
                    newCode += ("ST " + newTemp + "\n");
                }
                else if(params->Strings[op] == "+"){
                    newCode += ("L " + params->Strings[par1] + "\n");
                    newCode += ("A " + params->Strings[par2] + "\n");
                    newCode += ("ST " + newTemp + "\n");
                }
                else if(params->Strings[op] == "/"){
                    newCode += ("L " + params->Strings[par1] + "\n");
                    newCode += ("D " + params->Strings[par2] + "\n");
                    newCode += ("ST " + newTemp + "\n");
                }
                else if(params->Strings[op] == "*"){
                    newCode += ("L " + params->Strings[par1] + "\n");
                    newCode += ("M " + params->Strings[par2] + "\n");
                    newCode += ("ST " + newTemp + "\n");
                }
                else if(params->Strings[op] == "^"){
                    newCode += ("L " + params->Strings[par1] + "\n");
                    newCode += ("P " + params->Strings[par2] + "\n");
                    newCode += ("ST " + newTemp + "\n");
                }
                else if(params->Strings[op] == "="){
                    newCode += ("L " + params->Strings[par2] + "\n");
                    newCode += ("ST " + params->Strings[par1] + "\n");
                    //if it was an equals operation, might as well reset the temporaries
                    currentTempCount = 0;
                    newTemp = "";
                }

                //pop the last 3 items
                for(int h=0; h<3; h++) params->Delete(params->Count-1);

                if(newTemp != "")
                    params->Add(newTemp);

                if(verbosity > 0){
                    for(int z=0; z<level; z++) printf("  ");
                    printf("[---generating code---]\n");
                }

                code += newCode;

            } //if(codegen)

        } //for(units)

        if(allUnitsSuccessful) break;

    } //for(rules)

    return allUnitsSuccessful;
}
//---------------------------------------------------------------------------



