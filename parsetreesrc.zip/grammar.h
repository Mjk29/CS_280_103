//---------------------------------------------------------------------------
#ifndef grammarH
#define grammarH



class RewriteUnit{
public:
    String str;
    bool terminal;  //terminal or non
    bool codeGen;   //code generator statement
    RewriteUnit():str(""),terminal(false),codeGen(false){}
};
//------------------------------------


class RewriteRule{
public:
    //each rewrite rule contains a collection of rewrite units
    TList* units;
    RewriteRule(){ units = new TList(); }
    ~RewriteRule(){
        for(int i=0; i<units->Count; i++) delete ((RewriteUnit*)units->Items[i]);
        delete units;
    }
};
//------------------------------------


class RewriteRuleGroup{
public:
    //each rewrite rule group contains a collection of rewrite rules
    TList* rules;

    String nonTerminal; //non-terminal which this group rewrites
    int currentRule;

    RewriteRuleGroup():currentRule(0){ rules = new TList(); }
    ~RewriteRuleGroup(){
        for(int i=0; i<rules->Count; i++) delete ((RewriteRule*)rules->Items[i]);
        delete rules;
    }
    String Apply();
};
//------------------------------------


class Grammar{
public:
    //a grammar contains a collection of rewrite rule groups
    TList* ruleGroups;

    Grammar(){ ruleGroups = new TList(); }
    ~Grammar(){
        for(int i=0; i<ruleGroups->Count; i++) delete ((RewriteRuleGroup*)ruleGroups->Items[i]);
        delete ruleGroups;
    }

    void LoadFromFile(String fileName);
    void SaveToFile(String fileName);

    //For later on. (much later)
    String Apply(String nonTerminal);
    void EliminateIdentities();
    void EliminateEpsilonProductions();
    void EliminateLeftRecursion();
    void EliminateUnitProductions();
    void RightFactor();
};
//------------------------------------














//---------------------------------------------------------------------------
#endif
 